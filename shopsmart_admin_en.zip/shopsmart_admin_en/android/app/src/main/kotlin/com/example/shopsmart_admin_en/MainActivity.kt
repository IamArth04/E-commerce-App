package com.example.shopsmart_admin_en

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

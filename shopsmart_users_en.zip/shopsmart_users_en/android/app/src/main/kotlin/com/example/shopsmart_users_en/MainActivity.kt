package com.example.shopsmart_users_en

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
